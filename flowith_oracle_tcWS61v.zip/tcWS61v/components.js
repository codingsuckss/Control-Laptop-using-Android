export function createServiceCard(service) {
    return `
        <div class="service-card bg-white p-6 rounded-2xl border border-slate-100 h-full flex flex-col group cursor-pointer">
            <div class="h-48 rounded-xl bg-slate-100 overflow-hidden mb-6 relative">
                 <div class="absolute inset-0 bg-slate-900/10 group-hover:bg-transparent transition-colors z-10"></div>
                 <img src="${service.image}" alt="${service.title}" class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700">
            </div>
            <div class="flex items-center gap-3 mb-3">
                <div class="icon-wrapper w-10 h-10 rounded-full bg-solar-50 text-solar-500 flex items-center justify-center">
                    <i data-lucide="${service.icon}" class="w-5 h-5"></i>
                </div>
                <h3 class="font-serif font-semibold text-lg text-slate-900">${service.title}</h3>
            </div>
            <p class="text-slate-600 text-sm leading-relaxed flex-grow">
                ${service.description}
            </p>
            <div class="mt-6 pt-4 border-t border-slate-50 flex items-center text-solar-600 font-medium text-sm group-hover:translate-x-1 transition-transform">
                <span>Learn more</span>
                <i data-lucide="chevron-right" class="w-4 h-4 ml-1"></i>
            </div>
        </div>
    `;
}
