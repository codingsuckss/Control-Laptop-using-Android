import { servicesData } from './data.js';
import { createServiceCard } from './components.js';

document.addEventListener('DOMContentLoaded', () => {

    lucide.createIcons();


    const servicesGrid = document.getElementById('services-grid');
    if (servicesGrid) {
        servicesGrid.innerHTML = servicesData.map(service => createServiceCard(service)).join('');
        lucide.createIcons(); // Re-run for dynamic content
    }


    const observerOptions = {
        threshold: 0.1,
        rootMargin: "0px"
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = "1";
                entry.target.style.transform = "translateY(0)";
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);


    const animatedElements = document.querySelectorAll('.service-card, #hero-text, #hero-visual, section h2');
    animatedElements.forEach((el, index) => {
        el.style.opacity = "0";
        el.style.transform = "translateY(20px)";
        el.style.transition = "opacity 0.6s ease-out, transform 0.6s ease-out";
        el.style.transitionDelay = `${index * 0.1}s`; // Stagger effect
        observer.observe(el);
    });


    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('py-2');
            navbar.querySelector('.glass-panel').classList.add('shadow-md', 'bg-white/90');
        } else {
            navbar.classList.remove('py-2');
            navbar.querySelector('.glass-panel').classList.remove('shadow-md', 'bg-white/90');
        }
    });
});
