export const servicesData = [
    {
        id: 'on-grid',
        title: 'On-Grid System',
        description: 'Connect directly to the utility grid. Save on bills by exporting excess power.',
        icon: 'zap',
        image: 'https://images.unsplash.com/photo-1592833159057-65a2845730bd?q=80&w=2070&auto=format&fit=crop'
    },
    {
        id: 'hybrid',
        title: 'Hybrid System',
        description: 'The best of both worlds. Battery backup with grid connectivity for 24/7 power.',
        icon: 'battery-charging',
        image: 'https://images.unsplash.com/photo-1620714223084-8fcacc6dfd8d?q=80&w=2071&auto=format&fit=crop'
    },
    {
        id: 'off-grid',
        title: 'Off-Grid System',
        description: 'Complete independence from electricity companies. Perfect for remote locations.',
        icon: 'mountain',
        image: 'https://images.unsplash.com/photo-1548613053-220e75373678?q=80&w=2070&auto=format&fit=crop'
    },
    {
        id: 'water-pump',
        title: 'Solar Water Pump',
        description: 'Efficient irrigation solutions powered by the sun. Ideal for agriculture.',
        icon: 'droplets',
        image: 'https://images.unsplash.com/photo-1563293883-9b19e99a1945?q=80&w=1975&auto=format&fit=crop'
    }
];

export const companyInfo = {
    name: "Jagariya Solar Energy",
    phone: "7725893562",
    address: "133, Opposite Madhu Furniture, Behind SBI Bank, Mayur Market, Thatipur, Gwalior",
    subsidyAmount: "78,000"
};
